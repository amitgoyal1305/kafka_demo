package com.demo.demokafka.concumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class MessageConsumer {
    private static final Logger LOOGER = LoggerFactory.getLogger(MessageConsumer.class);
    @KafkaListener(topics = "test",groupId = "test")
    public void consume(String message){
        LOOGER.info(String.format("Message consume from topic : %s",message));
    }
}
