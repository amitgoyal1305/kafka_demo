package com.demo.demokafka.concumer;

import com.demo.demokafka.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class JsonConsumer {

    private static final Logger LOOGER = LoggerFactory.getLogger(JsonConsumer.class);
    @KafkaListener(topics = "json",groupId = "test")
    public void consume(User user){
        LOOGER.info(String.format("Message consume from topic : %s",user.toString()));

    }
}
