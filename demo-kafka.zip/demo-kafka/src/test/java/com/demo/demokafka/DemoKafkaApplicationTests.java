package com.demo.demokafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
